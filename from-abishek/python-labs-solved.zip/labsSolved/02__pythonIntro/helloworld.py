#!/usr/bin/env python3

# This is your first python code
# Please open 1.2-Script.md for instructions

# Step 2 - Print stuff and initialize variables
# ---Start Code Here---
print("Hello world!")
a = 10
b = 3.1
c = "world!"
# ---End Code Here---

# Step 4 - More experimenting with printing and operators
# ---Start Code Here---
print(a)
print(b)
print("Hello " + c)
print("Hello " + str(a))

p = a + b
q = a - b
r = a * b
s = a / b
print("a + b = " + str(p))
print("a - b = " + str(q))
print("a * b =", r)
print("a / b =", s)
# ---End Code Here---
