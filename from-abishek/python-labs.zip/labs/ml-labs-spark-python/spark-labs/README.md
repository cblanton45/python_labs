<link rel='stylesheet' href='assets/css/main.css'/>

# Spark labs
There are two tracks.
1. Scala
2. Python

## Scala track
Please see [spark-scala.md](spark-scala.md)

## Python track
- Open [README-python.html](README-python.html) in browser and follow the steps

## To Instructor
Please run
```
    ./package-labs.sh
```
To update HTML files and create a zip bundle
