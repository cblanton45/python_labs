SageMaker solutions are created by running SageMaker notebooks and saving them as HTML.

They can be used as demos, as well as solutions.
