# Machine Learning Labs for Spark Python

## To view the labs
Open 'README.html' in browser.  
(If the html files are missing run `./package-labs.sh`)

## To work on the labs
- Run the following command
```bash
    $  ./run-jupyter.sh
```
- And open the link printed on the console.

- And open `README.ipynb`
