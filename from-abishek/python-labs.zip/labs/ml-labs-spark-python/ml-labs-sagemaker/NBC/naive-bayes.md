# SageMaker NBC

### [Pre-requisites](../README.md)

NBC stands Naive Bayes Classifier

Not found on SageMaker (yet)