# SageMaker LDA

### [Pre-requisites](../README.md)

### STEP 0: Instructor demonstates the lab from a HTML page [here](es-training/machine-learning/solutions/ml-solutions-sagemaker/mnist)

### STEP 1: Log in into SageMaker

![alt text](../assets/sagemaker-console.png)

### STEP 2: Create notebook instance (if not already created)

![alt text](../assets/create-notebook-instance.png)

### STEP 3: Open the LDA

* Full path: introduction_to_amazon_algorithms/xgboost_mnist/xgboost_mnist.ipynb

### STEP 4: Set the S3 location. 

For example, we have set it to this

    bucket = 'elephantscale-sagemaker'

### STEP 5: Follow the steps in the notebook

* Follow the steps in the notebook
* Read the instructions
* Experiment with values
* Do not forget to clean up the endpoint

* Leave the instance itself running for future labs

