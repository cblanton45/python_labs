# AWS Redshift lab

### [Pre-requisites](../README.md)

### STEP 0: Instructor demonstates the lab from a HTML page [here](es-training/machine-learning/solutions/ml-solutions-sagemaker/mnist)

### STEP 1: Install a SQL tool

Since Redshift does not come with an SQL tool, you can do one of the following

* [Install psql ](https://gist.github.com/sgnl/609557ebacd3378f3b72)
