#!/usr/bin/env python3

# This is your first python code
# Please open 1.2-Script.md for instructions

# Step 2 - Print stuff and initialize variables
# ---Start Code Here---

# ---End Code Here---

# Step 4 - More experimenting with printing and operators
# ---Start Code Here---

# ---End Code Here---